package net.sytes.scarranaro.da;

public interface DABasic {

	
	
	
}
